#!/usr/bin/perl

use strict;

use constant PHRED_OFFSET => 33;

my($infile1, $outfile1, $infile2, $outfile2, $cutoff, $line, $line2, $name, $name2, @seq, @seq2, @newseq,@newseq2, $pos,
	@qual, @qual2, $i, $j, $val, $minsize, $cnt_lt, $continue, $new_name, $mean_qual1, $mean_qual2, $avg_thresh, $adaptor_seq, @data, @adaptor_subs);
if (@ARGV < 7) {
 print "Usage: fastq_to_fasta_paired <RawReadFile1> <RawReadFile2> <OutputFASTA1> <OutputFASTA2> QualityTrim3# MinReadLength# AvgQuality#\n";
}
else {
	$infile1=$ARGV[0];
	$outfile1=$ARGV[2];
	$infile2=$ARGV[1];
	$outfile2=$ARGV[3];
	$cutoff=$ARGV[4];
	$minsize=$ARGV[5];
	$avg_thresh=$ARGV[6];
	
	print "Looking for runs of 3 bases with PRED quality less than ", $cutoff, " ,average quality of $avg_thresh and length greater than or equal to $minsize\n";
		
	if (@ARGV>7) { $adaptor_seq=$ARGV[7];}
	else {$adaptor_seq="GATCGGAAGAGC";}
	
	@data=split(//, $adaptor_seq);
	for($i=0; $i<@data; $i++) {
		$adaptor_subs[$i]=substr($adaptor_seq, 0, @data-$i);
		#	for($j=0; $j<=$i; $j++) {
		#	$adaptor_subs[$i] =$adaptor_subs[$i] . $data[$j];
		#}
		#print "Substring $i: ", $adaptor_subs[$i], "\n";
	}
	#exit();

	#$cutoff=$cutoff*1;

	open(READDATA, "<" . $infile1) or die;
	if (!(-e $outfile1)) {
		open(WRITEDATA, ">" . $outfile1) or die;
	}
	else {print "Error: Output file $outfile2 exists\n"; die;}
	open(READDATA2, "<" . $infile2) or die;

	if (!(-e $outfile2)) {
		open(WRITEDATA2, ">" . $outfile2) or die;
	}
	else {print "Error: Output file $outfile2 exists\n"; die;}


	while(($line = <READDATA>) && ($line2=<READDATA2>)) {
		$line =~ s/\n//;
		$line2 =~ s/\n//;
		
		$name=$line;
		$name2=$line2;
		$line=<READDATA>;
		$line =~ s/\n//;
		#print "InitialSeq1 |$line|\n";
		
		if ($line =~ /$adaptor_subs[0]/) {
			$continue=0;
			$line =~ /$adaptor_subs[0]/;
			$pos =$-[0];
			$line=substr($line, 0, $pos);
		}
		else {
			$i=1;
			$continue=1;
			while($continue == 1) {
				if ($line =~ /$adaptor_subs[$i]$/) {
					$continue=0;
					$line =~ /$adaptor_subs[$i]$/;
					$pos =$-[0];
					$line=substr($line, 0, $pos);
				}
				else {
					if ($i == @adaptor_subs-1) {$continue=0;}
					else {$i++;}
				}
			}
		}
		#print "Seq after adaptor check: |$line|\n";
				
		@seq=split(//, $line);
		
		$line2=<READDATA2>;
		$line2 =~ s/\n//;
		
		#print "InitialSeq2 |$line2|\n";
		#print "Seq2 before adaptor check: |$line2|\n";
		if ($line2 =~ /$adaptor_subs[0]/) {
			$continue=0;
			$line2 =~ /$adaptor_subs[0]/;
			$pos =$-[0];
			$line2=substr($line2, 0, $pos);
			
		}
		else {
			$i=1;
			$continue=1;
			while($continue == 1) {
				if ($line2 =~ /$adaptor_subs[$i]$/) {
					$continue=0;
					$line2 =~ /$adaptor_subs[$i]$/;
					$pos =$-[0];
					$line2=substr($line2, 0, $pos);

				}
				else {
					if ($i == @adaptor_subs-1) {$continue=0;}
					else {$i++;}
				}
			}		
		}
		#print "Seq2  after adaptor check: |$line2|\n";
		
		
		
		@seq2=split(//, $line2);
		
		$line=<READDATA>;
		$line=<READDATA>;
		$line =~ s/\n//;
		
		$line2=<READDATA2>;
		$line2=<READDATA2>;
		$line2 =~ s/\n//;
		
		@qual=split(//, $line);
		@qual2=split(//, $line2);
		
		$cnt_lt=0;
		$continue=1;
		$i=0;
		@newseq=();
		#$val=0+$qual[0];
		$val=$qual[0];
		#print "Val is ", $val, " Cuttof is ", $cutoff, "\n";
		#$val=$val + 0;
		#print "After Val is ", $val, "\n";
		
		while (($i<@seq) && ($continue == 1) ) {
			#print "2: $i: Q: $val:: ", ord($val), "\n";
			if ((ord($val) - PHRED_OFFSET) < $cutoff) { $cnt_lt++;}
			if ($cnt_lt > 2) {$continue=0;}
			if ($continue == 1) {
				#print WRITEDATA $seq[$i];
				$newseq[$i]=$seq[$i];
				$i++;
				$val=$qual[$i];
			}
			#	$val=1*$qual[$i];
		}
		
		if ($continue == 0) {
			$line = join('', @newseq);
			$line = substr($line, 0, length($line)-2);
			@newseq=split(//, $line);
		}
		
		$cnt_lt=0;
		$continue=1;
		$i=0;
		@newseq2=();
		#$val=0+$qual[0];
		$val=$qual2[0];
		#print "Val is ", $val, " Cuttof is ", $cutoff, "\n";
		#$val=$val + 0;
		#print "After Val is ", $val, "\n";
		
		while (($i<@seq2) && ($continue == 1) ) {
			
			if ((ord($val) - PHRED_OFFSET) < $cutoff) { $cnt_lt++;}
			if ($cnt_lt > 2) {$continue=0;}
			if ($continue == 1) {
				#print WRITEDATA $seq[$i];
				$newseq2[$i]=$seq2[$i];
				$i++;
				$val=$qual2[$i];
			}
			#	$val=1*$qual[$i];
		}
		
		if ($continue == 0) {
			$line = join('', @newseq2);
			$line = substr($line, 0, length($line)-2);
			@newseq2=split(//, $line);
		}
		
		
		#print "Final__Seq1 |", @newseq, "|\n";
		#print "Final__Seq2 |", @newseq2, "|\n";
		
		$mean_qual1=0;
		for($i=0; $i<@qual; $i++) {$mean_qual1+= ord($qual[$i]) - PHRED_OFFSET;}
		$mean_qual1 = 1.0*$mean_qual1/(1.0*@qual);
		
		$mean_qual2=0;
		for($i=0; $i<@qual2; $i++) {$mean_qual2+= ord($qual2[$i]) - PHRED_OFFSET;}
		$mean_qual2 = 1.0*$mean_qual2/(1.0*@qual2);
		
		#print "Qual1: $mean_qual1, 2: $mean_qual2, ", @newseq-1, ": ", @newseq2-1,"\n";
		
		if ((@newseq > $minsize) && (@newseq2 > $minsize) && ($mean_qual1 >= $avg_thresh) && ($mean_qual2 >= $avg_thresh)) {
			$new_name=$name;
			$new_name =~ s/^@//;
			$new_name =~ s/^(\d|\w|_|-){8,25}://;
			$new_name =~ s/^(\d|\w|_|-){8,25}://;
			$new_name =~ s/^(\d|\w|_|-){3,25}://;
			$new_name =~ s/:/_/g;
			$new_name =~ s/\//_/g;
			print WRITEDATA ">", $new_name, "\n";

			for($i=0; $i<@newseq; $i++) {
				print WRITEDATA $newseq[$i];
			}
			print WRITEDATA "\n\n";
			
			$new_name=$name2;
			$new_name =~ s/^@//;
			$new_name =~ s/^(\d|\w|_|-){8,25}://;
			$new_name =~ s/^(\d|\w|_|-){8,25}://;
			$new_name =~ s/^(\d|\w|_|-){3,25}://;
			$new_name =~ s/:/_/g;
			$new_name =~ s/\//_/g;
			print WRITEDATA2 ">", $new_name, "\n";
			for($i=0; $i<@newseq2; $i++) {
				print WRITEDATA2 $newseq2[$i];
			}
			print WRITEDATA2 "\n\n";
			
		}
		
		
	}

	close READDATA;
	close WRITEDATA;
	close READDATA2;
	close WRITEDATA2;
}
