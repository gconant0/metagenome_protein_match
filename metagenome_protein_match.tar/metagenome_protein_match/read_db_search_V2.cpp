#include <seqan/sequence.h>
#include <seqan/basic.h>
#include <iostream>
#include <seqan/file.h>
#include <seqan/modifier.h>
#include <seqan/seq_io.h>
#include <seqan/index.h>
#include <seqan/align.h>
#include <seqan/score.h>
#include <string.h>
#include <map>
#include <queue>


#ifdef _OPEN_MP_VERSION_
#include "omp.h"
#endif

#define BATCH_SIZE 10000

using namespace seqan;

typedef Iterator<StringSet<seqan::String<AminoAcid> > >::Type TStringSetIterator;
typedef String<seqan::AminoAcid> TAASequence;                 // sequence type
typedef seqan::String<seqan::CharString> TName;
typedef Align<TAASequence,ArrayGaps> TAlign;      // align type
typedef Row<TAlign>::Type TRow; 
typedef Iterator<TRow>::Type TRowIterator;




double get_percent_id (TRow row1, TRow row2) {
	int  num_diff=0;
	TRowIterator it1, it2;
	
	it2=begin(row2);
	for(it1=begin(row1); it1 != end(row1); ++it1) {
		if ((*it1)!= (*it2)) num_diff++;
		++it2;
	}
	
	
	return(1.0 - ((double)num_diff/(double)length(row1)));
}




double string_to_float(char *instring)
{
	int i=0; 
	bool neg=false;
	double value, tenths=0.1;
	
	while(instring[i]<48 || instring[i]>57)
		i++;
	
	if (instring[i-1]=='-')
		neg=true;
	value=instring[i]-48;
	i++;
	
	while (instring[i]>=48 && instring[i]<=57)
	{
		value=value*10+(instring[i]-48);
		i++;
	}
	if (instring[i]=='.')
    {
		i++;
		while (instring[i]>=48 && instring[i]<=57)
		{
			value=value+((instring[i]-48)*tenths);
			tenths*=0.1;
			i++;
		}
    }
	
	if (neg)
		value=-1.0*value;
	
	return(value);
	
}



int string_to_int(char *instring)
{
	int i=0, value;
	int neg=-1;
	
	while(instring[i]<48 || instring[i]>57) {
		if ((instring[i]) == '-' &&( instring[i+1]>=48 && instring[i+1]<=57))
			neg=0;
		i++;
	}  
	value=instring[i]-48;
	i++;
	
	while (instring[i]>=48 && instring[i]<=57)
	{
		value=value*10+(instring[i]-48);
		i++;
	}
	
	if (neg==0)
		value *=-1;
	
	return(value);
} //End string_to_int


class Pair_for_Align {
public:
	Pair_for_Align() {id1=-1; id2=-1;};
	Pair_for_Align & operator= (Pair_for_Align &assign_from) {id1=assign_from.get_id1(); id2=assign_from.get_id2(); return(*this);};
	int operator== (const Pair_for_Align &comp_to) const;
	bool operator< (const Pair_for_Align &comp_to) const;
	void set_id1(int val) {id1=val;};
	void set_id2(int val) {id2=val;};
	void set_pair(int val1, int val2) {id1=val1; id2=val2;};
	int get_id1() const {return(id1);};
	int get_id2() const {return(id2);};
		
protected:
	int id1, id2;
};


int Pair_for_Align::operator== (const Pair_for_Align &comp_to)
const
{
	int ret_val=1; 
	
	if ((id1 != comp_to.get_id1()) || (id2 != comp_to.get_id2()) ) 
		ret_val=0; 
	return(ret_val);
}

bool Pair_for_Align::operator< (const Pair_for_Align &comp_to)
const
{
	int ret_val=0;
	
	if (id1 < comp_to.get_id1()) ret_val=1;
	else {
		if ((id1 == comp_to.get_id1()) && (id2 < comp_to.get_id2())) ret_val=1;
	}
	
	return(ret_val);
}

															

class  Int_Pair {
public:
	Int_Pair() {seq1=-1; seq2=-1;};
	Int_Pair & operator= (Int_Pair &assign_from) {seq1=assign_from.get_seq1(); seq2=assign_from.get_seq2(); return(*this);};
	int operator== (const Int_Pair &comp_to) const;
	bool operator< (const Int_Pair &comp_to) const;
	void set_seq1(int val) {seq1=val;};
	void set_seq2(int val) {seq2=val;};
	void set_pair(int val1, int val2) {seq1=val1; seq2=val2;};
	int get_seq1() const {return(seq1);};
	int get_seq2() const {return(seq2);};
	
protected:
	int seq1, seq2;
};




int Int_Pair::operator== (const Int_Pair &comp_to)
const
{
	int ret_val=1; 
	
	if ((seq1 != comp_to.get_seq1()) || (seq2 != comp_to.get_seq2())) 
		ret_val=0; 
	return(ret_val);
}

bool Int_Pair::operator< (const Int_Pair &comp_to)
const
{
	int ret_val=0;
	
	if (seq1 < comp_to.get_seq1()) ret_val=1;
	else {
		if ((seq1 == comp_to.get_seq1()) && (seq2 < comp_to.get_seq2())) ret_val=1;
	}
	
	return(ret_val);
}


typedef std::map<long unsigned int, Int_Pair>::iterator Map_Iter;


int main(int argc, char **argv)
{
	int i, res, my_thread_id=0;
	long unsigned int loc, curr_seqID, match_len, subpos, match_loc, id_offset=0, db_size=0, db_chunk, *db_id_offset;
	char inreads[100], indb[100];
	double percent_thresh, prop_align, prop, percent_id;
	bool filefinished, selfsearch=false;
	seqan::StringSet<seqan::CharString> ids, *db_ids;
	TName my_name;
	TAASequence curr_seq, curr_full_seq, db_seq, aligned_seqs[2];
    seqan::StringSet<TAASequence> seqs, *aa_dbs, full_db;
	TStringSetIterator *its;
	seqan::Finder<seqan::Index<seqan::StringSet<TAASequence>, seqan::IndexEsa<> > > **esaFinders;
	seqan::Index<seqan::StringSet<TAASequence >, seqan::IndexEsa<> > **indexSets; 
	
	Int_Pair my_pair, loc_pair;
	Pair_for_Align align_pair;
	std::map<long unsigned int, Int_Pair> *match_hashes;
	std::map<long unsigned int, TAASequence> *hit_sequences;
	std::map<long unsigned int, TName> *hit_names;
	Map_Iter *map_its;
	std::queue<Pair_for_Align> *use_pairs;
	Blosum62 scoreScheme;
	TAlign *aligners;
	TRow row1, row2;
	
   
	if (argc > 5) {
		strcpy(inreads, argv[1]);
		if (argv[2][0] == '-') {
			selfsearch=true;
			strcpy(indb, argv[1]);
		}
		else
			strcpy(indb, argv[2]);
		match_len=string_to_int(argv[3]);
		percent_thresh=string_to_float(argv[4]);
		prop_align=string_to_float(argv[5]);
		
		
	
		
#ifdef _OPEN_MP_VERSION_
#pragma omp parallel private(my_thread_id)
		{
			my_thread_id=omp_get_thread_num();
			if (my_thread_id == 0) {
				match_hashes=new std::map<long unsigned int, Int_Pair> [omp_get_num_threads()];
				use_pairs=new std::queue<Pair_for_Align>[omp_get_num_threads()];
				hit_sequences=new std::map<long unsigned int, TAASequence> [omp_get_num_threads()];
				hit_names=new std::map<long unsigned int, TName> [omp_get_num_threads()];
				map_its=new Map_Iter[omp_get_num_threads()];
				db_id_offset = new long unsigned int [omp_get_num_threads()];
				its = new TStringSetIterator[omp_get_num_threads()];
				aligners=new TAlign [omp_get_num_threads()];

				db_ids=new seqan::StringSet<seqan::CharString> [omp_get_num_threads()];
				aa_dbs=new seqan::StringSet<TAASequence> [omp_get_num_threads()];
				
				
				//seqan::SequenceStream seqStreamAll(indb);
                SeqFileIn seqFileIn(indb);
				//res = readAll(db_ids[0], full_db, seqStreamAll);
                readRecords(db_ids[0], full_db, seqFileIn);
                
                
				for (its[my_thread_id] = begin(full_db); its[my_thread_id] != end(full_db); ++its[my_thread_id]) db_size++;
				
				clear(full_db);
				clear(db_ids[0]);	
                close(seqFileIn);
                
                
				db_chunk=(long unsigned int)((double)db_size/(double)omp_get_num_threads())+1;
				
				//seqan::SequenceStream seqStream(indb);
                SeqFileIn seqFileInS(indb);
				for(i=0; i<omp_get_num_threads(); i++) {
					db_id_offset[i]=(long unsigned int)(i*db_chunk);
					//res = readBatch(db_ids[i], aa_dbs[i], seqStream, db_chunk);
                    readRecords(db_ids[i], aa_dbs[i], seqFileInS, db_chunk);
				}
                close(seqFileInS);
				
			}
			
			
		}
#else
		use_pairs=new std::queue<Pair_for_Align>[1];
		hit_sequences=new std::map<long unsigned int, TAASequence> [1];
		hit_names=new std::map<long unsigned int, TName> [1];
		match_hashes=new std::map<long unsigned int, Int_Pair> [1];
		map_its=new Map_Iter[1];
		its = new TStringSetIterator[1];
		db_id_offset = new long unsigned int [1];
		db_id_offset[0]=0;
		aligners=new TAlign [1];
		resize(rows(aligners[0]), 2);
		db_ids=new seqan::StringSet<seqan::CharString> [1];
		aa_dbs=new seqan::StringSet<TAASequence > [1];
        
        
		//seqan::SequenceStream seqStreamAll(indb);
		//res = readAll(db_ids[0], aa_dbs[0], seqStreamAll);
        SeqFileIn seqFileIn(indb);
        //res = readAll(db_ids[0], full_db, seqStreamAll);
        readRecords(db_ids[0], aa_dbs[0], seqFileIn);
#endif		
		
		
		
#ifdef _OPEN_MP_VERSION_
#pragma omp parallel private(my_thread_id)
		{
			my_thread_id=omp_get_thread_num();
			if (my_thread_id == 0) {
				indexSets = new seqan::Index<seqan::StringSet<TAASequence >, seqan::IndexEsa<> > * [omp_get_num_threads()];
				esaFinders=new seqan::Finder<seqan::Index<seqan::StringSet<TAASequence >, seqan::IndexEsa<> > > *[omp_get_num_threads()];
			}
		}
#pragma omp parallel for private (i)
		for(i=0; i<omp_get_num_threads(); i++) {
			resize(rows(aligners[i]), 2);
			indexSets[i] = new seqan::Index<seqan::StringSet<TAASequence >, seqan::IndexEsa<> > (aa_dbs[i]);
			esaFinders[i]=new seqan::Finder<seqan::Index<seqan::StringSet<TAASequence >, seqan::IndexEsa<> > >((*indexSets[i]));
			//std::cout<<"Thread "<<i<<" allocated its indices\n";
		}
#else
		indexSets = new seqan::Index<seqan::StringSet<TAASequence >, seqan::IndexEsa<> > * [1];
		indexSets[0] = new seqan::Index<seqan::StringSet<TAASequence >, seqan::IndexEsa<> > (aa_dbs[0]);
		esaFinders=new seqan::Finder<seqan::Index<seqan::StringSet<TAASequence >, seqan::IndexEsa<> > > *[1];
		esaFinders[0]=new seqan::Finder<seqan::Index<seqan::StringSet<TAASequence >, seqan::IndexEsa<> > >((*indexSets[0]));
#endif		
		
		
		
	//seqan::SequenceStream seqStream2(inreads);
        SeqFileIn seqFileIn2(inreads);

		
#ifdef _OPEN_MP_VERSION_
#pragma omp parallel private(curr_seq, loc, match_loc, my_pair, loc_pair, subpos, curr_full_seq, my_thread_id, curr_seqID, align_pair, my_name, db_seq, aligned_seqs, prop, percent_id, row1, row2)

		{
			my_thread_id=omp_get_thread_num();
#endif
		
			clear(seqs);
#ifdef _OPEN_MP_VERSION_
			if (my_thread_id == 0) {
#endif
                readRecords(ids, seqs, seqFileIn2, BATCH_SIZE);
                //res = readBatch(ids, seqs, seqStream2, BATCH_SIZE);
				//filefinished=atEnd(seqStream2);
                filefinished=atEnd(seqFileIn2);
                
                //std::cout<<"First name is "<<value(ids, 0)<<std::endl;
                
				//std::cout<<"Thread "<<my_thread_id<<" read a batch with result "<<res<<std::endl;
#ifdef _OPEN_MP_VERSION_
			}
#endif
#ifdef _OPEN_MP_VERSION_
#pragma omp barrier
			//std::cout<<"Thread "<<my_thread_id<<" has offset "<<id_offset<<std::endl;
#endif
            //std::cout<<"Entering search\n";
			
			while(!(filefinished && (length(seqs) == 0))) {
				for (its[my_thread_id] = begin(seqs); its[my_thread_id] != end(seqs); ++its[my_thread_id]) {
					subpos=0;
					curr_seqID= position(its[my_thread_id], seqs)+id_offset;
                    
					curr_full_seq=value(its[my_thread_id]);
					
                    //std::cout<<"Thread "<<my_thread_id<<": ID"<<curr_seqID<<" For : "<<value(ids, curr_seqID-id_offset)<<" Got: "<<curr_full_seq<<std::endl;
        
                    
					while ((length(curr_full_seq) - subpos) >= match_len) {
						curr_seq=infix(value(its[my_thread_id]),subpos, subpos+match_len);
						//std::cout<<"Thread "<<my_thread_id<<": SP"<<subpos<<" Got: "<<curr_seq<<std::endl;
						
						while(find((*esaFinders[my_thread_id]), curr_seq))
                        {
                            loc = getSeqNo(position((*esaFinders[my_thread_id])));
                            if ((!selfsearch) || ((loc+db_id_offset[my_thread_id]) != curr_seqID)) {
                                match_loc=getSeqOffset(position((*esaFinders[my_thread_id])));
                                //std::cout<<"Match for "<<curr_seqID<<" and "<<match_loc<<std::endl;
                                if (match_hashes[my_thread_id].find(loc) == match_hashes[my_thread_id].end()) {
                                    loc_pair.set_seq1(match_loc);
                                    loc_pair.set_seq2(-1);
                                    match_hashes[my_thread_id][loc] = loc_pair;
                                }
                                else {
                                    if (match_hashes[my_thread_id][loc].get_seq2() == -1) {
                                        if ((int)match_loc < match_hashes[my_thread_id][loc].get_seq1()) {
                                            loc_pair.set_seq1(match_loc);
                                            loc_pair.set_seq2(match_hashes[my_thread_id][loc].get_seq1());
                                            match_hashes[my_thread_id][loc] = loc_pair;
                                        }
                                        else {
                                            match_hashes[my_thread_id][loc].set_seq2((int)match_loc);
                                        }
                                    }
                                    else {
                                        if ((int)match_loc < match_hashes[my_thread_id][loc].get_seq1()) {
                                            match_hashes[my_thread_id][loc].set_seq1((int)match_loc);
                                        }
                                        if ((int)match_loc > match_hashes[my_thread_id][loc].get_seq2()) {
                                            match_hashes[my_thread_id][loc].set_seq2((int)match_loc);
                                        }
                                    }
                                }
                            }
                        }
							
						
						clear((*esaFinders[my_thread_id]));
						subpos++;
					}
						
					for(map_its[my_thread_id]=match_hashes[my_thread_id].begin(); map_its[my_thread_id]!=match_hashes[my_thread_id].end(); ++map_its[my_thread_id]) {
						if ((map_its[my_thread_id]->second.get_seq1()+(int)match_len) < map_its[my_thread_id]->second.get_seq2()) {
							align_pair.set_pair(curr_seqID, map_its[my_thread_id]->first);
							my_name=value(ids, curr_seqID-id_offset);
							
							if (hit_sequences[my_thread_id].find(curr_seqID) == hit_sequences[my_thread_id].end()) 
								hit_sequences[my_thread_id][curr_seqID]=curr_full_seq;
							if (hit_names[my_thread_id].find(curr_seqID) == hit_names[my_thread_id].end())
								hit_names[my_thread_id][curr_seqID]=value(ids, curr_seqID-id_offset);
							
                            //std::cout<<"Adding hit for "<<my_name<<std::endl;
                            //std::cout<<"Orig "<<value(ids, curr_seqID-id_offset)<<std::endl;
							use_pairs[my_thread_id].push(align_pair);
						}
					}
					match_hashes[my_thread_id].clear();
						

				
				}
				
				
				while (!use_pairs[my_thread_id].empty())
				{
					align_pair=use_pairs[my_thread_id].front();
					use_pairs[my_thread_id].pop();
					db_seq=value(aa_dbs[my_thread_id], (long unsigned int)align_pair.get_id2());
					curr_seq=hit_sequences[my_thread_id][align_pair.get_id1()];
					assignSource(row(aligners[my_thread_id], 0), curr_seq);
					assignSource(row(aligners[my_thread_id], 1), db_seq);
					localAlignment(aligners[my_thread_id], scoreScheme);
					
					//curr_seq=align_pair.get_seq();
					aligned_seqs[0]=infix(curr_seq, clippedBeginPosition(row(aligners[my_thread_id], 0)), clippedEndPosition(row(aligners[my_thread_id], 0))-1);
					aligned_seqs[1]=infix(db_seq, clippedBeginPosition(row(aligners[my_thread_id], 1)), clippedEndPosition(row(aligners[my_thread_id], 1))-1);
					row1=row(aligners[my_thread_id], 0);
					row2=row(aligners[my_thread_id], 1);
					
					
					prop = (double) (toSourcePosition(row1, length(row1))-toSourcePosition(row1, 0)) / (double)length(curr_seq);
					percent_id=get_percent_id(row1, row2);
                    //std::cout << db_ids[my_thread_id][align_pair.get_id2()] <<"\t"<<value(ids, (long unsigned int)align_pair.get_id1())<<"\t"<< percent_id <<std::endl;
					//std::cout <<"Test Match: " << db_ids[i][align_pair.get_id2()] <<"\t"<<align_pair.get_name()
					//<<"\t"<<prop<<"\t"<<percent_id<<" ALNLEN: "<<length(row1)
					//	<<" LEN: "<<length(align_pair.get_seq())<< "LEN2: "<<length(db_seq) 
					//	<<" S1 "<<align_pair.get_seq()<< " S2 "<<db_seq
					//<<" A1 "<<aligned_seqs[0] << " A2" << aligned_seqs[1] 
					//<<std::endl;
					if ((prop >= prop_align) && ( percent_id>= percent_thresh)) {
#ifdef _OPEN_MP_VERSION_
#pragma omp critical
						{
							std::cout <<"OMP"<< db_ids[my_thread_id][align_pair.get_id2()] <<"\t"<<hit_names[my_thread_id][align_pair.get_id1()]<<"\t"<< percent_id <<std::endl;
							//std::cout << db_ids[align_pair.get_id2()] << "\t" << percent_id <<std::endl;
						}
#else
						//std::cout << db_ids[my_thread_id][align_pair.get_id2()] <<"\t"<<hit_names[my_thread_id][align_pair.get_id1()]<<"\t"<< percent_id <<std::endl;
                        std::cout << db_ids[my_thread_id][align_pair.get_id2()] <<"\t"<<value(ids, (long unsigned int)align_pair.get_id1()-id_offset)<<"\t"<< percent_id <<std::endl;
#endif				
						//std::cout << value(seqs, my_pair.get_seq1()) <<" :: "<<value(aa_db, my_pair.get_seq2()) <<std::endl;
					}
				}
				
				hit_sequences[my_thread_id].clear();
				hit_names[my_thread_id].clear();
				
#ifdef _OPEN_MP_VERSION_
#pragma omp barrier
#endif
				
				if (my_thread_id == 0) {
					clear(seqs);
					clear(ids);
					//res = readBatch(ids, seqs, seqStream2, BATCH_SIZE);
					//filefinished=atEnd(seqStream2);
                    readRecords(ids, seqs, seqFileIn2, BATCH_SIZE);
                    //res = readBatch(ids, seqs, seqStream2, BATCH_SIZE);
                    //filefinished=atEnd(seqStream2);
                    filefinished=atEnd(seqFileIn2);
					id_offset+=BATCH_SIZE;
					//std::cout<<"Thread "<<my_thread_id<<" read a batch with result "<<res<<" We have reached: "<<id_offset<<std::endl;
				}
#ifdef _OPEN_MP_VERSION_
#pragma omp barrier
				//std::cout<<"Thread "<<my_thread_id<<" has offset "<<id_offset<<std::endl;
#endif
				
			}
#ifdef _OPEN_MP_VERSION_
			}
#endif
		
				
		
		delete[] hit_sequences;
		delete[] hit_names;
		delete[] use_pairs;
		
		return 0;
	}
	else {
		std::cerr <<"Usage: seqan_test <in reads> <in db>/-self <match len>  <percent ID> <prop align>\n";
		return(-1);
	}
}
